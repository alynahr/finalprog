/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.reward;

/**
 *
 * @author Lenovo
 */
public class Reward {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
